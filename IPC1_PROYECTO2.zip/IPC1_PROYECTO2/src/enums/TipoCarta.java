/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package enums;

/**
 *
 * @author Gio
 */
public enum TipoCarta {
    FUEGO,
    AGUA,
    PLANTA,
    ELECTRICO,
    PSIQUICO,
    NORMAL,
    OSCURO,
    ACERO;
}